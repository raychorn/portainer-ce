This file has moved to: https://docs.docker.com/compose/swarm/
