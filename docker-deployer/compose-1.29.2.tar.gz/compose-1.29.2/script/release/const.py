import os


REPO_ROOT = os.path.join(os.path.dirname(__file__), '..', '..')
